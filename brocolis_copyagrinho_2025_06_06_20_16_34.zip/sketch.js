let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let imgMachado; // Renomeado para imgMachado para maior clareza
let machado;

let tempoProximoMachado = 0; // Controla quando o machado vai aparecer
let intervaloMinMachado = 3000; // Tempo mínimo em milissegundos para o machado aparecer
let intervaloMaxMachado = 8000; // Tempo máximo em milissegundos para o machado aparecer

function preload() {
  imgMachado = loadImage("machado.png");
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
  machado = new Machado(); // Criamos uma instância do machado
  tempoProximoMachado = millis() + random(intervaloMinMachado, intervaloMaxMachado); // Define o primeiro aparecimento do machado
}

function draw() {
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
  mostrarInformacao();

  temperatura += 0.05; // Diminuí um pouco o aumento da temperatura
  if (temperatura > 30) temperatura = 30; // Limite a temperatura máxima para não ficar muito rápido

  jardineiro.mostrar();
  jardineiro.atualizar();

  // Desenha as plantas existentes
  for (let i = plantas.length - 1; i >= 0; i--) {
    plantas[i].mostrar();
  }

  // Lógica para o machado aparecer e cortar árvores
  if (millis() > tempoProximoMachado) {
    machado.aparecerAleatoriamente();
    machado.exibir();
    machado.cortarArvores(); // Chama a função para cortar árvores
    tempoProximoMachado = millis() + random(intervaloMinMachado, intervaloMaxMachado); // Define o próximo aparecimento
  }

  // O machado só é exibido se estiver "ativo" (já apareceu)
  if (machado.ativo) {
    machado.exibir();
  }
}

function mostrarInformacao() {
  textSize(20);
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text("Árvores plantadas: " + totalArvores, 10, 50);
  text("Para movimentar o personagem use as setas do teclado.", 10, 70);
  text("Pressione ESPAÇO ou 'P' para plantar árvores.", 10, 90);
}

// Classe que cria o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👨🏽‍🌾';
    this.velocidade = 3;
  }
  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }
    // Garante que o jardineiro não saia da tela
    this.x = constrain(this.x, 0, width - 32); // 32 é o tamanho aproximado do emoji
    this.y = constrain(this.y, 0, height - 32);
  }
  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

function keyPressed() {
  // Use `key` para verificar qual tecla foi pressionada
  if (key === ' ' || key === 'p' || key === 'P') { // Adicionei 'P' maiúsculo também
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
  }
  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

class Machado {
  constructor() {
    this.x = -1000; // Começa fora da tela
    this.y = -1000;
    this.ativo = false; // Indica se o machado está visível e ativo
    this.tamanho = 100; // Tamanho do machado
    this.tempoAtivo = 0; // Tempo em que o machado fica visível
    this.duracaoVisivel = 1000; // Duração em milissegundos que o machado fica visível
  }

  aparecerAleatoriamente() {
    this.x = random(width - this.tamanho);
    this.y = random(height - this.tamanho);
    this.ativo = true;
    this.tempoAtivo = millis(); // Registra o momento em que ele aparece
  }

  exibir() {
    if (this.ativo) {
      image(imgMachado, this.x, this.y, this.tamanho, this.tamanho);

      // Desativa o machado depois de um tempo
      if (millis() - this.tempoAtivo > this.duracaoVisivel) {
        this.ativo = false;
        this.x = -1000; // Move para fora da tela
        this.y = -1000;
      }
    }
  }

  cortarArvores() {
    if (plantas.length > 0) {
      let numArvoresParaCortar = floor(random(1, min(3, plantas.length) + 1)); // Corta entre 1 e 3 árvores, ou menos se houver poucas

      for (let i = 0; i < numArvoresParaCortar; i++) {
        let indiceAleatorio = floor(random(plantas.length));
        plantas.splice(indiceAleatorio, 1); // Remove a árvore do array
        totalArvores--;
        if (totalArvores < 0) totalArvores = 0; // Garante que o contador não seja negativo
        temperatura += 5; // Aumenta a temperatura ao cortar árvores
      }
    }
  }
}